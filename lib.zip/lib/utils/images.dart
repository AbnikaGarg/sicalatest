class Images {
  static const String logo = 'assets/images/Logo.jpg';
  static const String logo2 = 'assets/images/Logo2.png';
}
