import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:sica/models/OtherMemberProfile.dart';
import 'package:sica/services/member_repo.dart';
import 'package:sica/views/members/components/members_tabbar.dart';

import '../../components/member_card.dart';
import '../../theme/theme.dart';
import '../../utils/images.dart';

class Members extends StatefulWidget {
  const Members({super.key});

  @override
  State<Members> createState() => _nameState();
}

class _nameState extends State<Members> {
  List<OtherMemberProfile>? memberDetails;
  List<MemberBasicDetails>? memberBasicDetails;
  late ScrollController scrollController;
  bool isLoadedMore = false;
  bool hasNextPage = true;
  @override
  void initState() {
    super.initState();
    getMemberDetails();
    scrollController = ScrollController()..addListener(loadMore);
  }

  @override
  void dispose() {
    super.dispose();
    scrollController.dispose();
  }

  void loadMore() {
    if (hasNextPage == true &&
        isLoadedMore == false &&
        scrollController.position.maxScrollExtent == scrollController.offset) {
      isLoadedMore = true;
      page = page + 100;
      final service = MemberRepo();
      print(page);
      service.getAllMemberDetails(page.toString()).then((value) {
        if (value.isNotEmpty) {
           memberDetails = value;
          if (memberDetails!.first.memberBasicDetails!.isNotEmpty) {
            memberBasicDetails =
                memberBasicDetails!  + memberDetails!.first.memberBasicDetails!;
          } else {
            hasNextPage = false;
          }
          isLoadedMore = false;
          if (mounted) setState(() {});
        }
      });
    }
  }

  int page = 100;
  void getMemberDetails() {
    final service = MemberRepo();
    service.getAllMemberDetails(page.toString()).then((value) {
      if (value.isNotEmpty) {
        memberDetails = value;
        memberBasicDetails = value.first.memberBasicDetails;
        if (mounted) setState(() {});
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        //  backgroundColor: AppTheme.backGround2,
        appBar: AppBar(
          titleSpacing: 0,
          elevation: 0,
          title: Text("All Members"),
          actions: [
            IconButton(
                onPressed: null,
                icon: Icon(
                  Icons.search,
                  color: AppTheme.bodyTextColor,
                ))
          ],
        ),
        body: SingleChildScrollView(
          physics: AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
          controller: scrollController,
          child: Column(
            children: [
              SizedBox(
                height: 10.h,
              ),
              if (memberBasicDetails != null)
                if (memberBasicDetails!.isNotEmpty)
                  ListView.builder(
                   primary: false,
                   shrinkWrap: true,
                    itemCount: memberBasicDetails!.length,
                    itemBuilder: (context, index) {
                  return GestureDetector(
                    onTap: () {
                      Navigator.of(context).push(MaterialPageRoute(
                          builder: (context) => MembersTabBar(
                                memberdetail: memberBasicDetails![index],
                              )));
                    },
                    child: MemberCard(
                      name: memberBasicDetails![index]
                          .memberDetails!
                          .name
                          .toString(),
                      designation: memberBasicDetails![index]
                          .memberDetails!
                          .designation
                          .toString(),
                      date: memberBasicDetails![index]
                          .memberDetails!
                          .joiningDate
                          .toString(),
                      memberno: memberBasicDetails![index]
                          .memberDetails!
                          .membershipNo
                          .toString(),
                      image: memberBasicDetails![index]
                          .memberDetails!
                          .image
                          .toString(),
                    ),
                  );
                    },
                  ),
                  if (hasNextPage == false)
              Container(
                padding: EdgeInsets.symmetric(vertical: 20.h),
                child: const Center(
                  child: Text('no more Records'),
                ),
              )
            else
              Container(
                  alignment: Alignment.center,
                  color: Theme.of(context).scaffoldBackgroundColor,
                  child: Padding(
                    padding: EdgeInsets.symmetric(vertical: 20.h),
                    child: const CupertinoActivityIndicator(
                      radius: 12,
                    ),
                  ))
              //   else
              //     Center(
              //       child: Text("No Records"),
              //     )
              // else
              //   Center(
              //     child: CircularProgressIndicator(),
             //   ),
            ],
          ),
        ));
  }
}
