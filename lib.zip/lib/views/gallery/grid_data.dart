class GridData{
  final int id;
  final String name;
  final String image;

  GridData(this.id, this.name, this.image);
}

