import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../utils/images.dart';

class AboutSica extends StatelessWidget {
  const AboutSica({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        leading: GestureDetector(
            onTap: () {
              Navigator.pop(context);
            },
            child: const Icon(Icons.arrow_back)),
        elevation: 1,
        title: const Text("About SICA"),
      ),
      body: Container(
          padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 16.h),
          margin: EdgeInsets.symmetric(horizontal: 12.w, vertical: 20.h),
          decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              borderRadius: BorderRadius.circular(8),
              border:
                  Border.all(color: Colors.grey.withOpacity(0.4), width: 1)),
          child: Column(
            children: [
              Center(
                child: Image.asset(
                  Images.logo2,
                  fit: BoxFit.cover,
                  width: 180.w,
                ),
              ),
              SizedBox(height: 30.h),
              Text(
                "The Southern India Cinematographers Association, SICA, was started on 27th November 1972. Mr. A. Vincent was the Founder-President, Mr.P.N.Sundaram the General Secretary and Mr. S. Maruthi Rao the Treasurer. The main objective was to engage with the management of studios and producers to secure better emoluments, job security and fair remuneration and benefits. SICA is a TRADE UNION of all South Indian Cinematographers and is affiliated to the Film Employees Federation of South India (FEFSI).\n\nToday SICA aims to further the artistic interest of the cinematographers, educate and keep abreast with the latest technical achievements in the field, protect the commercial interests and look after the welfare of its members. Technical Qualification, Knowledge and Experience is the primary criteria for membership. The Membership today is Classified under ACTIVE Cameraman, ASSOCIATE Cameraman and JUNIORS.",
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
          )),
    );
  }
}
